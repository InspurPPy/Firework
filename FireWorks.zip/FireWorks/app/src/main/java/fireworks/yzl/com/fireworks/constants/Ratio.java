package fireworks.yzl.com.fireworks.constants;

public class Ratio {
    public static float SCREEN_WIDTH = 0;
}
